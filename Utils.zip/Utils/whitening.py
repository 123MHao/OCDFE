import numpy as np
from scipy import linalg
import torch


class ZCA(object):
    def __init__(self, regularization=1e-5, x=None):
        self.regularization = regularization
        if x is not None:
            self.fit(x)

    def fit(self, x):
        s = x.shape
        x = x.copy().reshape((s[0],np.prod(s[1:])))
        m = np.mean(x, axis=0)
        x -= m
        sigma = np.dot(x.T,x) / x.shape[0]
        U, S, _ = linalg.svd(sigma)
        self.S = S
        tmp = np.dot(U, np.diag(1./np.sqrt(S+self.regularization)))
        tmp2 = np.dot(U, np.diag(np.sqrt(S+self.regularization)))
        self.ZCA_mat = torch.from_numpy(np.dot(tmp, U.T)).float()
        self.inv_ZCA_mat = torch.from_numpy(np.dot(tmp2, U.T)).float()
        self.mean = torch.from_numpy(m).float()

    def apply(self, x):
        s = x.shape
        if isinstance(x, np.ndarray):
            return np.dot(x.reshape(s[0],np.prod(s[1:])) - self.mean.numpy(), self.ZCA_mat.numpy()).reshape(s)
        elif isinstance(x, torch.Tensor):
            return torch.matmul(x.view(s[0],-1) - self.mean, self.ZCA_mat).reshape(s)
        else:
            raise NotImplementedError("Whitening only implemented for numpy arrays or torch Tensor")

    def invert(self, x):
        s = x.shape
        if isinstance(x, np.ndarray):
            return (np.dot(x.reshape(s[0], np.prod(s[1:])),
                           self.inv_ZCA_mat.numpy()) + self.mean.numpy()).reshape(s)
        elif isinstance(x, torch.Tensor):
            return (torch.matmul(x.view(s[0],-1), self.inv_ZCA_mat) + self.mean).reshape(s)
        else:
            raise NotImplementedError("Whitening only implemented for numpy arrays or Theano TensorVariables")