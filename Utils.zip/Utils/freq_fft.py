import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as st

def do_fft_norm(x):
    """
    conduct fft, then normalize the amplitude
    Args:
        x: a sliced vector with zero mean

    Returns: normalized amplitude

    """
    xx0_fft=np.abs(np.fft.fft(x))*2/len(x) # normalization constant: 2/N
    xx0_fft=xx0_fft[:len(x)//2] # take half of the symmetric result
    return xx0_fft

def do_matrix_fft_norm(X):
    """
    conduct fft to a matrix, then normalize the amplitude
    Args:
        X: a 2d numpy array (matrix) with row the number of samples, and column the number of data points

    Returns: normalized amplitude

    """
    length=X.shape[1] # the number of columns
    xx0_fft=np.abs(np.fft.fft(X,axis=1))*2/length # normalization constant: 2/N
    xx0_fft=xx0_fft[:,:length//2] # take half of the symmetric result
    return xx0_fft

def freq_Analysis(x, samplingfrequency):
    """
    conduct fft on raw vibration signal, and then plot the frequency spectrum
    Args:
        x: raw vibration signal, with a certain
        samplingfrequency: sampling frequency

    Returns: plots

    """
    block_size=len(x)
    x -= np.mean(x)
    x = do_fft_norm(x)
    freqAxis = samplingfrequency * np.array(range(block_size//2)) / block_size
    # plt.axis([0,6000,0,0.2])
    plt.plot(freqAxis,x)
    plt.title("Frequency Spectrum")
    plt.show()

def freq_spec_coords(x, samplingfrequency):
    """
    conduct fft on raw vibration signal, and then return its frequency spectrum (axis and normalized amplitude)
    Args:
        x: raw vibration signal, with a certain
        samplingfrequency: sampling frequency

    Returns: frequency spectrum, x and y coordinates

    """
    block_size=len(x)
    x -= np.mean(x)
    y = do_fft_norm(x)
    freqAxis = samplingfrequency * np.array(range(block_size//2)) / block_size
    return freqAxis,y



def fre_features(x,samplingfrequency):
    block_size = len(x)
    x -= np.mean(x)
    y = do_fft_norm(x)
    freqAxis = samplingfrequency * np.array(range(block_size // 2)) / block_size

    fp1 = np.mean(y)
    fp2=np.std(y)
    fp3=st.skew(y)
    fp4=st.kurtosis(y)
    meanf=np.dot(y,freqAxis)/np.sum(y)
    fp5=meanf   ##频率中心特征，反映主频带位置的变化
    sigma=np.sqrt(np.dot(np.power(freqAxis-meanf,2),y)/block_size)
    fp6=sigma   ## 表示频谱的分散或集中程度
    fp7=np.sqrt(np.dot(np.power(freqAxis,2),y)/np.sum(y))  ##均方根频率，反映主频带位置的变化
    fp8=np.sqrt(np.dot(np.power(freqAxis,4),y)/np.dot(np.power(freqAxis,2),y))
    fp9 = np.dot(np.power(freqAxis, 2), y)/np.sqrt(np.sum(y)*np.dot(np.power(freqAxis,4),y))
    fp10=sigma/meanf
    fp11=np.dot(np.power(freqAxis-meanf,3),y)/(sigma**3*block_size)
    fp12=np.dot(np.power(freqAxis-meanf,4),y)/(sigma**4*block_size)
    fp13=np.dot(np.sqrt(np.abs(freqAxis-meanf)),y)/(np.sqrt(sigma)*block_size)

    return np.array([fp1,fp2,fp3,fp4,fp5,fp6,fp7,fp8,fp9,fp10,fp11,fp12,fp13])


def awgn(x, snr):
    """

    Args:
        x: it can be a numpy array or a vector
        snr: signal to noise ratio, measured in dB

    Returns:
        x+noise,
    """
    assert (isinstance(x, np.ndarray))
    snr = 10**(snr/10.0)
    if x.ndim==1:
        xpower = np.sum(x**2)/len(x)
        npower = xpower / snr
        noise = np.random.randn(len(x)) * np.sqrt(npower)
    elif x.ndim==2:
        xpower = np.sum(x**2,axis=1)/x.shape[1]
        npower = xpower /snr
        npower=np.sqrt(npower).reshape(-1,1)
        noise = np.random.randn(*x.shape) * npower  ## matrix times a vector
    return x+noise

